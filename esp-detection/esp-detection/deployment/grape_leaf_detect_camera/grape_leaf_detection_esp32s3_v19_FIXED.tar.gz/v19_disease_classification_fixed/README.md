# ESP32-S3 Grape Leaf Detection v19 (Model Name Fixed)

**Firmware Version**: v19_disease_classification_fixed  
**Build Date**: January 10, 2026  
**Compile Time**: 11:27  
**Critical Fix**: Corrected model name to include `.espdl` extension

## 🔧 What's Fixed in v19

### Root Cause Found
**v18 was still failing** because the model name was missing the `.espdl` extension!

- ❌ **v18 used**: `"mobilenetv2_128_grape_leaf"` (wrong)
- ✅ **v19 uses**: `"mobilenetv2_128_grape_leaf.espdl"` (correct)

The detection model works because it uses: `"espdet_pico_320_320_grape_leaf.espdl"` (with extension).

### Technical Details
ESP-DL's packed binary format stores model names **with** the `.espdl` extension:
```
Packed Binary Header (from hexdump):
0x0020: espdet_pico_320_320_grape_leaf.espdl
0x0040: mobilenetv2_128_grape_leaf.espdl
```

When loading, you must use the **exact name** as stored in the packed binary.

### Debug Output from v18
```
I (1606) DiseaseClassifier: 📦 Packed binary found:
I (1606) DiseaseClassifier:    Start: 0x3c1542b0
I (1616) DiseaseClassifier:    End:   0x3c40f5a0
I (1616) DiseaseClassifier:    Size:  2863856 bytes (2.73 MB)  ✓ CORRECT
I (1626) DiseaseClassifier:    Header (first 32 bytes):
I (1626) DiseaseClassifier:    0000: 50 44 4c 32 ...  ✓ "PDL2" magic correct
E (1656) FbsLoader: Unsupported format, or the model file is corrupted!  ❌ Wrong name
```

**The packed binary was perfect** - only the lookup name was wrong!

## 📦 Package Contents

```
v19_disease_classification_fixed/
├── bootloader.bin          (23 KB)
├── partition-table.bin     (3 KB)
├── grape_leaf_detect.bin   (4.27 MB)  ← Fixed model loading
├── flash_v19.sh            - Linux/Mac
├── flash_v19.bat           - Windows  
└── README.md               - This file
```

## 🚀 Quick Flash

### Windows
```cmd
cd v19_disease_classification_fixed
flash_v19.bat COM6
```

### Linux/Mac
```bash
cd v19_disease_classification_fixed
./flash_v19.sh /dev/ttyUSB0
```

## ✅ Expected Output (v19)

```
I (1576) DiseaseClassifier: Loading MobileNetV2 model: mobilenetv2_128_grape_leaf.espdl
I (1606) DiseaseClassifier: 📦 Packed binary found:
I (1616) DiseaseClassifier:    Size:  2863856 bytes (2.73 MB)
I (1626) DiseaseClassifier:    Header: 50 44 4c 32 (PDL2 ✓)
I (1646) DiseaseClassifier: 🔄 Creating dl::Model instance...
I (1666) DiseaseClassifier: 🔄 Validating model by getting input shape...
I (1680) DiseaseClassifier: ✓ Model loaded and validated successfully
I (1690) DiseaseClassifier: ✓ Model input shape: [1, 128, 128, 3]
I (1700) DiseaseClassifier: ✓ Allocated 49152 bytes in PSRAM
I (1710) DiseaseClassifier: ✅ Disease classifier initialization complete!
I (1720) grape_leaf_detect: ✓ Disease classifier initialized in 150 ms
```

**NO MORE FbsLoader errors!** 🎉

## 🔬 Models Included

Both models correctly embedded:

1. **Detection**: `espdet_pico_320_320_grape_leaf.espdl` (479 KB)
2. **Classification**: `mobilenetv2_128_grape_leaf.espdl` (2.3 MB)

**Total packed size**: 2.73 MB

## 🐛 Debugging History

### v17 - Missing Model
- Binary built before MobileNetV2 added to CMakeLists.txt
- Only detection model in binary (~500 KB)
- Crash: "Unsupported format"

### v18 - Wrong Model Name  
- Both models in binary (2.73 MB ✓)
- Correct header ("PDL2" ✓)
- **Wrong**: Used `"mobilenetv2_128_grape_leaf"` without `.espdl`
- Still crashed: "Unsupported format"

### v19 - FIXED! ✅
- Both models in binary (2.73 MB ✓)
- Correct header ("PDL2" ✓)  
- Correct name: `"mobilenetv2_128_grape_leaf.espdl"` with extension
- **Should work!**

## 📊 Performance (Expected)

```
Camera Capture    →  30 ms
JPEG Decode       →  100 ms
Detection         →  285 ms
Classification    →  150 ms (3 crops × 50ms)
────────────────────────────────
Total            →  ~565 ms (~1.8 FPS)
```

## 🔧 Hardware

- **ESP32-S3** QFN56 v0.2
- **8MB PSRAM** (Octal, AP_3v3)
- **16MB Flash**
- **OV3660 Camera** (640×480 VGA)

## 📝 Code Changes (v18 → v19)

**app_main.cpp** line 147:
```cpp
// OLD (v18):
disease_classifier->init("mobilenetv2_128_grape_leaf")

// NEW (v19):
disease_classifier->init("mobilenetv2_128_grape_leaf.espdl")  ← Added .espdl
```

That's it! One line fix.

## 🎯 Testing Checklist

After flashing v19:
- [ ] System boots without crash
- [ ] Detection model initializes (~140ms)
- [ ] Disease classifier initializes (~150ms)  
- [ ] No "FbsLoader: Unsupported format" errors
- [ ] Camera captures frames
- [ ] Detection inference works
- [ ] Disease classification works on crops
- [ ] Serial output shows full pipeline

## 📧 Support

If v19 still fails:
1. Check serial output for exact error message
2. Verify packed binary size shown is ~2.73-2.86 MB
3. Confirm header shows "50 44 4c 32" (PDL2)
4. Check model name in error log matches filename in header hexdump
5. Report specific DiseaseClassifier log lines

---

**Build**: Jan 10 2026 11:27  
**Fix**: Model name must include `.espdl` extension  
**Status**: Should work! 🤞
