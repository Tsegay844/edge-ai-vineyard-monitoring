# ESP32-S3 Grape Leaf Disease Detection Firmware v26
## Hybrid Aggregation with Improved Preprocessing

**Build Date:** January 14, 2026 03:32 UTC  
**Version:** v26  
**Target:** ESP32-S3 (QFN56, 8MB PSRAM, 16MB Flash)  
**ESP-IDF:** v5.3.3  

---

## 🎯 Key Improvements in v26

### 1. **Lowered Classification Threshold**
- **Old (v25):** 0.5 confidence threshold → Only 2-3 leaves classified
- **New (v26):** 0.3 confidence threshold → Expected 5-7 leaves classified
- **Impact:** More leaves analyzed for better disease coverage

### 2. **Letterbox Preprocessing with Aspect Ratio Preservation**
- **Old:** Direct bbox stretch to 128×128 (distorts leaf shape)
- **New:** Letterbox padding with aspect ratio maintained
  - Expand bbox to square (max dimension)
  - Center leaf in square frame
  - Add gray padding (127) for out-of-bounds pixels
  - Resize to 128×128 without distortion
- **Impact:** Better MobileNetV2 input quality, improved classification accuracy

### 3. **Fixed Filtering Bug**
- **Old:** Counted valid leaves but processed wrong indices (included low-confidence detections)
- **New:** Collect valid detections into separate vector, process only those
- **Impact:** Only high-confidence leaves (≥0.3) are classified

### 4. **Hybrid Aggregation Enabled**
- **Entropy Weighting:** ON (weights by prediction certainty)
- **Spatial Weighting:** ON (weights by bbox quality)
- **Impact:** More accurate final disease assessment

---

## 📊 Expected Results vs v25

| Metric | v25 | v26 (Expected) |
|--------|-----|----------------|
| **Leaves Classified** | 2-3 | 5-7 |
| **Classification Diversity** | Often single class | Multiple classes |
| **Aspect Ratio Preserved** | ❌ Distorted | ✅ Preserved |
| **Filtering Accuracy** | ⚠️ Bug present | ✅ Fixed |
| **Aggregation Quality** | Baseline | Hybrid (entropy + spatial) |

---

## 🔧 Hardware Requirements

- **Board:** ESP32-S3 with OV3660 camera
- **PSRAM:** 8MB (required for models)
- **Flash:** 16MB (recommended)
- **Camera:** OV3660 (640×480 JPEG)

---

## 📦 Package Contents

```
v26_hybrid_improved/
├── bootloader.bin          (23 KB)
├── partition-table.bin     (3 KB)
├── grape_leaf_detect.bin   (4.2 MB)
├── README.md              (this file)
├── flash_v26.sh           (Linux/Mac flash script)
└── flash_v26.bat          (Windows flash script)
```

---

## ⚡ Flash Instructions

### Linux/Mac:
```bash
cd v26_hybrid_improved
chmod +x flash_v26.sh
./flash_v26.sh
```

### Windows:
```cmd
cd v26_hybrid_improved
flash_v26.bat
```

### Manual Flash (Any Platform):
```bash
python -m esptool --chip esp32s3 -p /dev/ttyUSB0 -b 460800 \
  --before default_reset --after hard_reset write_flash \
  --flash_mode dio --flash_size 8MB --flash_freq 80m \
  0x0 bootloader.bin \
  0x8000 partition-table.bin \
  0x10000 grape_leaf_detect.bin
```

**Note:** Replace `/dev/ttyUSB0` with your actual port:
- Linux: `/dev/ttyUSB0` or `/dev/ttyACM0`
- Mac: `/dev/cu.usbserial-*` or `/dev/tty.usbserial-*`
- Windows: `COM3`, `COM4`, etc.

---

## 🔍 How to Monitor

### View Serial Output:
```bash
idf.py monitor -p /dev/ttyUSB0
```

Or using screen:
```bash
screen /dev/ttyUSB0 115200
```

Or using PuTTY (Windows):
- Port: COM3 (or your port)
- Baud: 115200
- Connection type: Serial

---

## 📝 What to Look For

### Detection Output:
```
Detected 10 objects (360 ms)
Sorted by confidence (highest first)
Running disease classification on top 7 detections:
  [0] Bbox: [120,80,220,180] (10000 px²), Leaf_Confidence: 0.850
      Disease Probability:
         • healthy: 75.00%
         • esca: 15.00%
         • black_rot: 10.00%
  [1] Bbox: [350,120,450,220] (10000 px²), Leaf_Confidence: 0.720
      Disease Probability:
         • esca: 85.00%
         • black_rot: 15.00%
  ...
```

### Aggregation Output:
```
WEIGHTED DISEASE AGGREGATION RESULTS:
  Method: HYBRID (Entropy + Spatial Weighting)
  Samples: 7 leaves

  Final Disease Distribution:
    • esca: 45.20%
    • healthy: 30.50%
    • black_rot: 20.30%
    • leaf_blight: 4.00%

  Individual Leaf Weights:
    Leaf 0: w=0.180 (entropy=0.85, bbox_quality=0.90)
    Leaf 1: w=0.165 (entropy=0.92, bbox_quality=0.85)
    ...
```

---

## 🐛 Known Issues

- **Minor Warnings:** Unused variables in crop preprocessing (cosmetic only, no impact)
- **Build Size:** 4.2 MB (17% of 5 MB partition free)

---

## 🔄 Changes from v25

### Code Changes:
1. **app_main.cpp**
   - Line 322: `CONF_THRESHOLD = 0.3f` (was 0.5f)
   - Lines 326-334: Fixed filtering to collect valid detections
   - Line 360: Use `valid_detections[i]` instead of `results_vec[i]`
   - Lines 445-446: Hybrid aggregation enabled

2. **disease_classifier.hpp**
   - Lines 160-210: Complete rewrite of `crop_and_resize()`
   - Added letterbox padding with aspect ratio preservation
   - Gray padding (127) for out-of-bounds pixels
   - Square bbox expansion centered on leaf

### Binary Changes:
- **v25 Size:** 4,356,496 bytes
- **v26 Size:** 4,356,368 bytes (-128 bytes, negligible difference)

---

## 📖 Testing Checklist

- [ ] Flash firmware successfully
- [ ] Device boots and shows system info
- [ ] Camera captures frames (640×480)
- [ ] Detection model runs (~360ms)
- [ ] **5-7 leaves classified** (vs 2-3 in v25)
- [ ] **Multiple disease classes detected** (healthy, esca, black_rot, leaf_blight)
- [ ] Hybrid aggregation shows entropy and bbox_quality values
- [ ] Individual leaf weights vary based on quality
- [ ] 5-minute capture interval working

---

## 🎓 Research Notes

This firmware version demonstrates:
- **Adaptive Thresholding:** Balancing detection quality vs coverage
- **Aspect Ratio Preservation:** Critical for CNN input quality
- **Bug-Free Filtering:** Ensuring correct high-confidence samples
- **Hybrid Aggregation:** Combining multiple quality metrics for robust disease assessment

Use v26 vs v25 comparison for thesis results on preprocessing and aggregation improvements.

---

## 📞 Support

For issues or questions, check serial output for error messages. Common issues:
- **Camera init failed:** Check connections, power supply
- **Model init failed:** Verify PSRAM available (8MB required)
- **No detections:** Check lighting, focus, leaf visibility

---

**Built with:** ESP-IDF v5.3.3 | ESP-DL 3.2.2 | MobileNetV2 | YOLO-based Detection
