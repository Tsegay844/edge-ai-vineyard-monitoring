@echo off
REM Flash script for ESP32-S3 Grape Leaf Detection v26
REM Usage: flash_v26.bat [PORT]

setlocal EnableDelayedExpansion

echo ===============================================
echo   ESP32-S3 Grape Leaf Detection Firmware v26  
echo ===============================================
echo.

REM Default port
set PORT=%1
if "%PORT%"=="" set PORT=COM3

REM Check if esptool is installed
python -m esptool version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: esptool not found
    echo Install with: pip install esptool
    pause
    exit /b 1
)

REM Check if binaries exist
if not exist "bootloader.bin" (
    echo Error: bootloader.bin not found
    echo Make sure you're in the v26_hybrid_improved directory
    pause
    exit /b 1
)
if not exist "partition-table.bin" (
    echo Error: partition-table.bin not found
    pause
    exit /b 1
)
if not exist "grape_leaf_detect.bin" (
    echo Error: grape_leaf_detect.bin not found
    pause
    exit /b 1
)

echo Flashing to: %PORT%
echo Baud rate: 460800
echo.
echo Press Ctrl+C to cancel or
pause

REM Flash command
echo.
echo Starting flash...
python -m esptool --chip esp32s3 -p %PORT% -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 8MB --flash_freq 80m 0x0 bootloader.bin 0x8000 partition-table.bin 0x10000 grape_leaf_detect.bin

if %errorlevel% equ 0 (
    echo.
    echo ===============================================
    echo   Flash completed successfully! [OK]
    echo ===============================================
    echo.
    echo To monitor serial output, use:
    echo   - PuTTY: Port=%PORT%, Baud=115200, Serial
    echo   - Arduino IDE Serial Monitor
    echo   - idf.py monitor -p %PORT%
    echo.
) else (
    echo.
    echo ===============================================
    echo   Flash failed! [ERROR]
    echo ===============================================
    echo.
)

pause
