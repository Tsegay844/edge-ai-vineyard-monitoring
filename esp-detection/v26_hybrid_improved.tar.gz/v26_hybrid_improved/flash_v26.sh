#!/bin/bash
# Flash script for ESP32-S3 Grape Leaf Detection v26
# Usage: ./flash_v26.sh [PORT]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${GREEN}  ESP32-S3 Grape Leaf Detection Firmware v26  ${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"

# Default port
PORT="${1:-/dev/ttyUSB0}"

# Check if esptool is installed
if ! command -v esptool.py &> /dev/null; then
    echo -e "${RED}Error: esptool.py not found${NC}"
    echo "Install with: pip install esptool"
    exit 1
fi

# Check if port exists
if [ ! -e "$PORT" ]; then
    echo -e "${YELLOW}Warning: Port $PORT not found${NC}"
    echo "Available serial ports:"
    ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null || echo "No serial ports found"
    echo ""
    read -p "Enter port (or press Enter for /dev/ttyUSB0): " user_port
    PORT="${user_port:-/dev/ttyUSB0}"
fi

# Check if binaries exist
if [ ! -f "bootloader.bin" ] || [ ! -f "partition-table.bin" ] || [ ! -f "grape_leaf_detect.bin" ]; then
    echo -e "${RED}Error: Binary files not found${NC}"
    echo "Make sure you're in the v26_hybrid_improved directory"
    exit 1
fi

echo ""
echo -e "${YELLOW}Flashing to: $PORT${NC}"
echo -e "${YELLOW}Baud rate: 460800${NC}"
echo ""
echo "Press Ctrl+C to cancel..."
sleep 2

# Flash command
echo -e "${GREEN}Starting flash...${NC}"
python3 -m esptool --chip esp32s3 -p "$PORT" -b 460800 \
  --before default_reset --after hard_reset write_flash \
  --flash_mode dio --flash_size 8MB --flash_freq 80m \
  0x0 bootloader.bin \
  0x8000 partition-table.bin \
  0x10000 grape_leaf_detect.bin

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  Flash completed successfully! ✓             ${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
    echo ""
    echo "To monitor serial output:"
    echo -e "${YELLOW}  screen $PORT 115200${NC}"
    echo "  or"
    echo -e "${YELLOW}  idf.py monitor -p $PORT${NC}"
    echo ""
else
    echo ""
    echo -e "${RED}═══════════════════════════════════════════════${NC}"
    echo -e "${RED}  Flash failed! ✗                             ${NC}"
    echo -e "${RED}═══════════════════════════════════════════════${NC}"
    exit 1
fi
